
public class FirstProgram {
  public static void main(String[] args) {
    System.out.print("Аз съм Катя Любенова");
    System.out.println(" и живея в София.");
}
}

