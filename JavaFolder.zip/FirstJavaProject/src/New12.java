
public class New12 {
	public static void main(String[] args) {
		int variable =1;
		System.out.println(variable);
		variable =2;
		System.out.println(variable);
		variable =3;
		System.out.println(variable);
		variable =4;
		System.out.println(variable);
	}

}



