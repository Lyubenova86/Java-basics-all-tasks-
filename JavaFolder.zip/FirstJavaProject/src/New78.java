
public class New78 {
	public static void main(String[] args) {
		double result;
		double digit2 = -3.0;
		double digit3 = -10.0;
		result = digit2 / digit3;
		System.out.println(result);
	}

}
