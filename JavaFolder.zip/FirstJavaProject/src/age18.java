import java.util.Scanner;

public class age18 {
	  public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter age");
		 int age = sc.nextInt();
		 boolean vote = false;
		 if(age >=18); {
			 vote =true;
			 System.out.println("Vleznah v If-a");
			 System.out.println("Pulnoleten e");
		 }
	  }
}

	  


