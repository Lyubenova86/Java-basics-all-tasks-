
public class wholeName {
	public static void main(String[] args) {
		String s1 = "Ivan";
		String s2 = "Ivanov";
		String s3 = "Georgiev";
		System.out.println(s1 + " " + s2 + " " + s3);
	}
}
