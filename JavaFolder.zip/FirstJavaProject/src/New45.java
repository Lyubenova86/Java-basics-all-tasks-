
public class New45 {
	public static void main(String[] args) {
		int number = 2;
		++number;
		--number;
		System.out.println(number);
	}

}



