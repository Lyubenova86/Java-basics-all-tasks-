package dataStructures2;

public class Cars {
    public static void main(String args)[]) {
    	String[] phoneBrands = new String [3];
    	phoneBrands[0] = "Nokia";
    	phoneBrands[1] = "Samsung";
    	phoneBrands[2] = "iPhone";
    	
    	for int i = 0, (i < phoneBrands.lenght; i++) {
    		phoneBrands[i] = " ala bala";
    		System.out.println(phoneBrands[i]);
    	}
    	
    }
}
