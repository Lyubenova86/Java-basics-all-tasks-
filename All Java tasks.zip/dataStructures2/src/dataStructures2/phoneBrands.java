package dataStructures2;

public class phoneBrands {
		public static void main(String args[]){
		String[] carBrands = {"Audi", "Bmw", "Volvo", "Mercedes"};
		carBrands[1] = "Karuca";
		System.out.println(carBrands[1]);
		}
		}


