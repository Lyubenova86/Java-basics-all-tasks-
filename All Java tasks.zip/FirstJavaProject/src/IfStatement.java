
public class IfStatement {
	public static void main(String[] args) {
		int i = 100;
		if (i > 50); {
			System.out.println("i e po-golyamo ot 50"); 
			}
		if (i < 100) {
			System.out.println("i e po-malko ot 120");
		}
		else {
			System.out.println("test");
		}
		}
	}


