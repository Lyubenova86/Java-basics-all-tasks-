import java.util.Scanner;

public class Firstname {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name: ");
		String firstName = sc.nextLine();
		System.out.println("My first name is: " + firstName);
	
	}
}
