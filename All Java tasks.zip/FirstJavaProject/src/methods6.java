
public class methods6 {

}
