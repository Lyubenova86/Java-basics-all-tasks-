
public class helloJavaIam {
	public static void main(String[] args) {
		String s1 = "Hello Java, ";
		String s2 = "I am Katya!";
		String s3 = s1 +s2;
		System.out.println(s3);
	}
}
