
public class sumNumbers {
	public static void main(String[] args) {
		int s1 = 2;
		int s2 = 5;
		int s3 = s1 + s2;
		System.out.println(s3);
	}

}
