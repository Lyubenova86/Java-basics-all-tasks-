
public class methods4 {
	public static void main(String args[]) {
       greeting("Ani", "Sofia");
       greeting("Ivan", "Varna");
		  }
			  public static void greeting (String name, String town) {
				 System.out.println ("Hello, " + name + "." + " "+ "You are in " + town);
			  }
}
