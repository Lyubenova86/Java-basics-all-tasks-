
public class sumDigits {
	public static void main(String[] args) {
	int sum;
	int digit1 = 8;
	int digit2 = -2;
	int digit3 = 10;
	sum = digit1 + digit2 + digit3;
	System.out.println(sum);
	}
}
