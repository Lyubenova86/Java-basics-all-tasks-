
public class methods_task1 {
   public static void main(String[] args) {
	   double sum = calculateTotal(5.5, 6.8, 8.3);
	   System.out.println(sum);
   }
	   public static double calculateTotal(double x, double y, double z) {
		   double sum = x + y + z;
		   return sum;
   }
	   
}
