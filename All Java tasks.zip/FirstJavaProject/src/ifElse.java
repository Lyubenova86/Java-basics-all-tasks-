
public class ifElse {
		public static void main(String[] args) {
			int i = 100; 
			@SuppressWarnings("unused")
			boolean test = true;
			if(i >= 100) {
				System.out.println("i e po-golyamo ili ravno na 100");
			}
			else {
				System.out.println("i e po-malko ot 100");
				
			}
		}
}
