
public class IterationsListsTask {

public class iterationListtask6 {

	{ 
	    for (int i = 0; i < l; i++) { 
	        if (a[i] % n != 0) 
	            return false; 
	    } 
	    return true; 
	} 
}

int main() 
{ 
    int a[] = {14, 12, 4, 18}; 
    int n = 2; 
    int l = (sizeof(a) / sizeof(a[0])); 
    if (findNoIsDivisibleOrNot(a, n, l)) 
        cout << "Yes"; 
    else
        cout << "No"; 
  
    return 0; 
} 



//Given a list iterate it and display numbers which are divisible by 5 and if you find number greater than 150 stop the loop
//iteration list1 = [12, 15, 32, 42, 55, 75, 122, 132, 150, 180, 200]
}
