import java.util.Scanner;

public class Task1Masivi {
		public static void main(String args[]){
			
		String[] phoneBrands = {"Nokia", "Samsung", "iPhone"};
				System.out.println(phoneBrands[3]);
		}
}

				